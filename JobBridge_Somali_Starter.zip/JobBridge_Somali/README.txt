# JobBridge Somali — prototype

## Open the prototype
Open `index.html` in a modern browser. It is a static demo and does not need a server.

## Included
- Somali / English interface toggle
- Sample job listings and search/category filtering
- Job-seeker registration form
- Demo applications and applicant dashboard
- EVC Plus payment-reference submission flow
- Admin demo panel to review applicants, update application statuses, verify payment references, and export demo data

## Important limitations before real launch
This prototype stores data in the browser's localStorage. It is not a production website:
- Registration/login is not secure and passwords are not stored or authenticated.
- Data is only available in the same browser/device and can be cleared by the user.
- EVC Plus is NOT connected. Payment references are only submitted for manual demo review. To accept real payments, arrange official merchant access/integration with the payment provider and verify transactions server-side.
- A production version needs a backend/database, secure authentication, role-based admin access, file upload/storage for CVs, HTTPS, privacy terms, backups, and abuse protection.
- The job listings are examples, not real vacancies.
